# Instagram User Stalker
(Chrome Extension)

* To see the latest photo the user has posted

To Do: 
* Allow login so users can download their other private users
* Allow download of photos
