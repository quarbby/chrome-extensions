window.addEventListener('load', loadHandler);

var accessToken = "220267872.99919c3.e717494ec46741b2b1805ee5aa821cc0";
var userName = "";
var userID = "";

function loadHandler() {
	document.getElementById('clickButton').addEventListener('click', initialGetUserPhoto);
	//initialGetUserPhoto();
}

function initialGetUserPhoto() {
	userName = document.getElementById('user').value;
	//userName = "beautifuldestinations";
	console.log(userName);
	
	getUserPhoto();
}

function getUserPhoto() {
	if (isEmptyString(userName)) {
		showEmptyUserMessage();
	} else {
		setErrorMessageNull();
		getUserID(userIDCallback);
	}
}

function isEmptyString(userString) {
	return userString == "";
}

function showEmptyUserMessage() {
	document.getElementById("error").innerHTML = "Whoops, user name cannot be empty!";
}

function setErrorMessageNull() {
		document.getElementById("error").innerHTML = "";
}

// Just getting the first user on the list 
function getUserID(userIdCallback) {
	var url = "https://api.instagram.com/v1/users/search?q=" + userName
				+ "&access_token=" + accessToken;
				
	jQuery.ajax({
		type: 'GET',
		url: url,
		data: {},
		dataType: 'json',	
		success: userIdCallback,
		error: function() {
			console.error("Some error happened"); 
			document.getElementById("error").innerHTML = "Whoops, not a valid Instagram user";
		}
	});			
}

var userIDCallback = function userIdCallback(data, textStatus, xhr) {
	//console.log(data);
	var length = data.data.length;
	if (length == 0) {
		showNoUserExistMessage();
	}
	else {
		//console.log(length);
		userID = data.data[0].id;
		//console.log(userID);
		// Temp userID = 276192188
		
		loadPhotoPage();
	}
}

function showNoUserExistMessage() {
		document.getElementById("error").innerHTML = "Whoops, no such user exists!";
}

function loadPhotoPage() {
	window.location.href = "photo.html?userID=" + userID;
}
