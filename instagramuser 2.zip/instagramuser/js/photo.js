window.addEventListener('load', loadHandler);

var accessToken = "220267872.99919c3.e717494ec46741b2b1805ee5aa821cc0";

var userName = "";
var caption = "";
var link = "";
var userID = "";
var imgUrl = "";

function loadHandler() {
	document.getElementById('clickButton').addEventListener('click', getUserPhoto);
	document.getElementById('newButton').addEventListener('click', loadIndexPage)
	
	getUserId();
}

function getUserPhoto() {
	console.log("Get User Photo");
	getJSON(userCallback);
}

function loadIndexPage() {
	console.log("Stalk New User");
	window.location.href = "index.html";
}

function getUserId() {
	var queryString = location.search.substring(1);
	
	userID = queryString.split("=")[1];
	//console.log(userID);
	
	getJSON(userCallback);
}

function getJSON(userCallback) {
	var url = "https://api.instagram.com/v1/users/" + userID
			+ "/media/recent/?access_token=" + accessToken
			+ "&count=1";
			
	//console.log(url);
	jQuery.ajax({
		type: 'GET',
		url: url,
		data: {},
		dataType: 'json',	
		success: userCallback,
		error: function() {
			console.error("Some error happened"); 
			document.getElementById("error").innerHTML = "Whoops, some error happened";
		}
		});
}

var userCallback = function callback(data, textStatus, xhr) {
	//console.log(data)
	var dataObj = data.data[0];
	userName = dataObj.caption.from.username;
	caption = dataObj.caption.text;
	link = dataObj.link;
	imgUrl = dataObj.images.standard_resolution.url;
	
	console.log(userName + " " + caption + " " + link + " " + imgUrl)
	
	setData();
}

function setData() {
	var usertitle = document.getElementById('usertitle');
	usertitle.innerHTML = userName + "'s Latest Photo";
	
	var captionObj = document.getElementById('caption');
	captionObj.innerHTML = caption;
	
	var userlink = document.getElementById('userlink');
	var a = document.createElement('a');
	userlink.appendChild(a);
	a.setAttribute('href', link);
	a.setAttribute('target', '_newtab');
	a.innerHTML = "View on Instagram";
	
	displayImg();
}

function displayImg() {
	console.log(link);
	
	var imgObj = document.getElementById('img-container');
	var img = document.createElement('img');
	img.src = imgUrl;
	img.width = 320;
	img.height = 320;
	imgObj.appendChild(img);
}