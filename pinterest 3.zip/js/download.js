window.addEventListener('load', loadHandler);

function loadHandler() {
	document.getElementById('clickButton').addEventListener('click', download);
	//download();
}

function download() {
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
		var url = tabs[0].url;
		console.log(url);

		// Temp Valid URL
		//url = "https://www.pinterest.com/pin/7670261842420490/";

		if(isValidUrl(url)) {
		    console.log("Valid URL");
		    document.getElementById("error").innerHTML = "";
		}
		else {
			console.log("Invalid URL");
			document.getElementById("error").innerHTML = "Whoops, not a valid Instagram URL";
		}

		getJSON(url, callback);

		});
}


function isValidUrl(url) {
	var pinterestInUrl = checkIfPinterestInUrl(url);
	return pinterestInUrl;
}

function checkIfPinterestInUrl(url) {
	if (url.match(/https\:\/\/www\.pinterest\.com\/pin/i)) {
		return true;
	} else {
		return false;
	}
}

//http://stackoverflow.com/questions/9951045/pinterest-api-documentation
function getJSON(url, callback) {
	var shortcode = getShortCode(url);
	var url = "https://api.pinterest.com/v3/pidgets/pins/info/?pin_ids=" +
			  shortcode; 

	console.log(url);

	console.log("Getting Pin");
	jQuery.ajax({
		type: 'GET',
		url: url,
		data: {},
		dataType: 'jsonp',	//Stand alone web app should be jsop; else json
		success: callback,
		error: function() {
			console.error("Some error happened"); 
			document.getElementById("error").innerHTML = "Whoops, not a valid Pinterest URL";

		}
	});

}

function getShortCode(url) {
	var splitString = url.split("/");
	var shortcodeIndex = splitString.indexOf("pin") + 1;
	var shortcode = splitString[shortcodeIndex];

	//console.log(shortcode);

	return shortcode;
}

var callback = function callback(data, textStatus, xhr) {
	var status = data.status;
	if (status != "success") {
		console.log("Invalid photo");
		document.getElementById("error").innerHTML = "Whoops, not a valid Pinterest URL";
		return;
	}

	var parsedJSON = data.data[0].images;
	var stringJSON = JSON.stringify(parsedJSON);
	var httpIndex = stringJSON.indexOf("http");
	var jpgIndex = stringJSON.indexOf("jpg");
	var picURL = stringJSON.substring(httpIndex, jpgIndex+2+1);
	console.log(picURL);

	downloadPic(picURL);
}

function downloadPic(picURL) {
	var splitURL = picURL.split("/");
	var filename = splitURL[splitURL.length -1];

	var xhr = new XMLHttpRequest();
	xhr.responseType = 'blob';

	xhr.onload = function() {
	    var a = document.createElement('a');
	    a.href = window.URL.createObjectURL(xhr.response); 
	    a.download = filename; 
	    a.style.display = 'none';
	    document.body.appendChild(a);
	    a.click();
	    delete a;
  };

  xhr.open('GET', picURL);
  xhr.send();
}
